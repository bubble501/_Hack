/* ϵͳ */
#include <stdio.h>
#include <fcntl.h>
#include <memory.h>
#include <errno.h>
#include <sys/types.h>
#include <assert.h>
#include <locale.h>
#include <math.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#define DLLEXPORT __stdcall
#else
#include <dlfcn.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
#define DLLEXPORT  
#endif

//����GTPAPIͷ�ļ�
#include "gtpApiGM.h"
#include "sgesafe.h"

int gtpLogin(char* traderid, char* accessid);
int traderLogin(char* traderid, char* accessid);
int regRecv(char* accessid);

#ifdef _WIN32
DWORD WINAPI ThreadFun(LPVOID pM)
{
	int ret = 0;
	ret = gtpLogin((char*)pM, (char*)pM);
	if (ret != 0)
		return -1;
	traderLogin((char*)pM, (char*)pM);
	regRecv((char*)pM);
	return 0;
}
#else
void* ThreadFun(void* pM)
{
	int ret = 0;
	ret = gtpLogin((char*)pM, (char*)pM);
	if (ret == 0)
	{
		traderLogin((char*)pM, (char*)pM);
		regRecv((char*)pM);
	}
}
#endif


//������Ϣִ�еĻص�����
 int  DLLEXPORT printcallback(CALLBACK_MESSAGE *pcallback_message)
{
	printf("receive msg: seqid[%s],logid[%d], msgtype[%s], content: %s\n", pcallback_message->header.csequenceSeriesNo , pcallback_message->ilogID
		,pcallback_message->header.cmsgType, pcallback_message->cpmessage);
	return 0;
}
//������Ϣִ�еĻص�����
 void DLLEXPORT  printcallErrorback(int code)
{
	printf("receive error[%d]\n", code);
	return ;
}
//���շ�����ʱ��
 void DLLEXPORT  printcallUTCTimeBack(int pcallHeartTimeBack)
{
	printf("UTC time[%d]\n", pcallHeartTimeBack);
	return ;
}

 //��ȫ�ص�����
 SAFE_FUNC safe_func;
 //�Ự��Կ
 unsigned char _sessionKey[200];

 int DLLEXPORT init()
 {
	 //���ü��ܻ�API���Ӽ��ܻ�����ʼ������
	 return 0;
 }

 int DLLEXPORT clear()
 {
	 //���ü��ܻ�API�Ͽ����ܻ�����
	 return 0;
 }

 int DLLEXPORT getpubkey(char* traderID, int type, unsigned char *pPubKey, int* nPubKeyLen)
 {
	 int ret = 0;
	 printf("callback safe_GetPubKey\n");
	  return 0; //���ü��ܻ�APIȡ�øý���Ա��������֤��Կ��ӽ��ܹ�Կ
 }
 int DLLEXPORT confirmkey(char* traderID, unsigned char *pCipherKey, int nCipherKeyLen, unsigned char *pSessionKey, int *pSessionKeyLen)
 {
	 printf("callback safe_ConfirmSessionKey\n");
	 int ret = 0;//���ü��ܻ�API���ܻỰ��Կ
	 memset(_sessionKey, 0x00, 200);
	 memcpy(_sessionKey, pSessionKey, *pSessionKeyLen);
	 return ret;
 }
 int DLLEXPORT encrypt(char* traderID, unsigned char* pOrgData, int nOrgDataSize, unsigned char  *pSessionKey, unsigned char* pOutData, int *pOutDataSize)
 {
	 printf("callback safe_SM4Encrypt\n");
	  return 0;//���ü��ܻ�API���ܱ��ģ�SM4�㷨��ʹ�ûỰ��Կ��
 }
 int DLLEXPORT decrypt(char* traderID, unsigned char* pOrgData, int nOrgDataSize, unsigned char  *pSessionKey, unsigned char* pOutData, int *pOutDataSize)
 {
	 printf("callback safe_SM4Decrypt\n");
	 return 0; //���ü��ܻ�API���ܱ��ģ�SM4�㷨��ʹ�ûỰ��Կ��
 }
 int DLLEXPORT sign(char* traderID, unsigned char* pOrgData, int nOrgDataSize, unsigned char* pSignData, int* pSignDataSize)
 {
	 printf("callback safe_Sign\n");
	 return 0; //���ü��ܻ�API���ñ���ǩ��˽Կǩ������
 }
 int DLLEXPORT verify(char* traderID, unsigned char* sgePubKey, int sgePubKeyLen, unsigned char* pOrgData, int nOrgDataSize, unsigned char* pSignData, int nSignDataSize)
 {
	 printf("callback safe_VerifySign\n");
	 return 0; //���ü��ܻ�API���ý�����ǩ����Կ��ǩ
 }

 int DLLEXPORT mac(char* traderID, unsigned char* pSessionKey, unsigned char* pOrgData, int nOrgDataSize, unsigned char* pMacData, int* nMacDataSize)
 {
	 printf("callback safe_SM4Mac\n");
	return 0; //���ü��ܻ�API��ʹ�ûỰ��Կ����mac
 }

 int gtpLogin(char* traderid, char* accessid)
 {
	 int ret = 0;
	 BREAK_DATA_INFO breakData;

	 //ѯ�۲�ѯ��4����Ϣ���ϵ���Ϣ
	 memset(&breakData, 0x00, sizeof(BREAK_DATA_INFO));
	 breakData.breakInfo[0].csequenceSeriesNo = '3';
	 breakData.breakInfo[0].isequenceNo = 1;
	 breakData.breakInfo[1].csequenceSeriesNo = '4';
	 breakData.breakInfo[1].isequenceNo = 1;
	 breakData.breakInfo[2].csequenceSeriesNo = '6';
	 breakData.breakInfo[2].isequenceNo = 1;
	 breakData.breakInfo[3].csequenceSeriesNo = '7';
	 breakData.breakInfo[3].isequenceNo = 1;
	 //��¼
	 ret = GTPLogin("127.0.0.1,", "9333", traderid, accessid, "abc123", &breakData);
	 if (ret != 0) {
		 printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!login fail [%s] ret=[%d]\n", traderid, ret);
		 return ret;
	 }
	printf("login success[%s]\n", traderid);
	//ע����Ϣ���ջص�����
	ret = GTPMsgRec(traderid, printcallback, printcallErrorback, printcallUTCTimeBack);

}

//����Ա��¼
int traderLogin(char* traderid, char* accessid)
{
	int ret=0;
	HEADER header;
	char *ctmpbuf1 = NULL;
	char *temp = NULL;
	printf("traderLogin started\n");
	char *string1 = NULL;
	unsigned int logID=0;

	ctmpbuf1 = (char*) malloc(20000);
	memset(ctmpbuf1, 0x00, 20000);

	memset(&header, 0x00, sizeof(HEADER));
	char* pwd = "E99A18C428CB38D5F260853678922E03"; //md5
	string1 = "M60=";
	temp = ctmpbuf1;
	memcpy(temp, string1,  strlen(string1));
	temp += strlen(string1);
	memcpy(temp, traderid, strlen(traderid));
	temp += strlen(traderid);
	string1 = ",M62=";
	memcpy(temp, string1, strlen(string1));
	temp += strlen(string1);
	memcpy(temp, pwd, strlen(pwd));
	header.cbeginString = NULL;    //��ѡ����
	header.ccontentLength = NULL;  //��ѡ����
	header.cmsgType = "A400";     //������
	header.csequenceSeriesNo = "1"; //������
	header.csequenceNo = "0"; //������
	header.cchainFlag = "S";   //��ѡ����
	ret = GTPMsgSend(accessid, &header, ctmpbuf1, &logID);
	if(ret != 0){
		printf("send msg error ret=[%d]\n", ret);
	}else{
		printf("send msg done logID=[%d]\n", logID);
	}
	return 0;
}

//����������Ϣ
int regRecv(char* accessid)
{
	int ret = 0;
	HEADER header;
	char *ctmpbuf1 = NULL;
	printf("regRecv started\n");
	char *string1 = NULL;
	unsigned int logID = 0;
	ctmpbuf1 = (char*)malloc(20000);
	memset(ctmpbuf1, 0x00, 20000);

	memset(&header, 0x00, sizeof(HEADER));

	string1 = "X22=";
	memcpy(ctmpbuf1, string1, strlen(string1));
	memcpy(ctmpbuf1+ strlen(string1), accessid, strlen(accessid));

	header.cbeginString = NULL;    //��ѡ����
	header.ccontentLength = NULL;  //��ѡ����
	header.cmsgType = "A200";     //������
	header.csequenceSeriesNo = "1"; //������
	header.csequenceNo = "0"; //������
	header.cchainFlag = "S";   //��ѡ����
	ret = GTPMsgSend(accessid, &header, ctmpbuf1, &logID);
	if (ret != 0) {
		printf("send msg error ret=[%d]\n", ret);
	}
	else {
		printf("send msg done logID=[%d]\n", logID);
	}
	return 0;
}

//GTPAPI.dll����main
int main(int argc, const char * const * argv, const char * const*env)
{
	char traderid[5][20] = { "pmx6003","pwh5003","pzm4003","pzy1003","pzw3003" };
	char accessid[5][20] = { "pmx6003","pwh5003","pzm4003","pzy1003","pzw3003" };
	int ret = 0;
	int i = 0;
	unsigned int logID = 0;

	printf("test start\n");

	//��ʼ������
	safe_func.init = init;
	safe_func.clear = clear;
	safe_func.getPubKey = getpubkey;
	safe_func.sign = sign;
	safe_func.verify = verify;
	safe_func.confirmkey = confirmkey;
	safe_func.encrypt = encrypt;
	safe_func.decrypt = decrypt;
	safe_func.mac = mac;
	ret = GTPEnvInit(&safe_func);
	if (ret != 0) {
		printf("init error [%d]\n", ret);
		return 0;
	}

	const static int count = 1;

#ifdef _WIN32
	HANDLE handlers[count];
	for (i = 0; i < count; i++)
	{
		handlers[i] = CreateThread(NULL, 0, ThreadFun, (void*)traderid[i], 0, NULL);
	}
	DWORD dw = WaitForMultipleObjects(count, handlers, TRUE, 30000);
	Sleep(30000);
#else
	pthread_t tid[count];
	for (i = 0; i < count; i++)
	{
		if (pthread_create(&tid[i], NULL, ThreadFun, (void*)traderid[i]) == -1)
			printf("create thread error:");
	}
	for (i = 0; i < count; i++)
	{
		pthread_join(tid[i], NULL);
	}
	sleep(30);
#endif
		
	//�ǳ��û�
	for (i = 0; i<count; i++)
	{
		ret = GTPLogout(traderid[i]);
		printf("[%s] logout done...\n", traderid[i]);
	}
    return 0;
}
